<?php

/**
 * Test fixture.
 *
 * Used in the `PHPMailer\LocalizationTest` to test overruling an existing translation
 * file with a custom one by passing in a `$langPath` parameter.
 */

$PHPMAILER_LANG['empty_message'] = 'Custom path test success (nl)';
