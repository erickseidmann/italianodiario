<?php

//These are global functions without a namespace used for testing validator injection
function php()
{
    return false;
}

function phpx()
{
    return false;
}
